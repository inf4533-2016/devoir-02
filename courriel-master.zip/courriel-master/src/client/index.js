var $          = require('jquery');
var NodeRSA    = require('node-rsa');
var CryptoJS   = require('crypto-js');
var superagent = require('superagent');

var $focus = $('#focus');
var $body  = $('#body');


var key = null;
var etat = null;
var decryptedLetters = [];

var decryptMessage = function( msg ) {
    var resultat = "Failed to decrypt";
    try {
        resultat = key.decrypt(msg, 'utf8');
    } catch (e) {
        console.warn("Problem: " + e);
    }
    return resultat;
}

var populateDecryptedLetters = function() {
    myPublicKey = key.exportKey('public');
    decryptedLetters = [];
    etat.letters.forEach( function( letter ) {
        if (letter.to == myPublicKey) {
            decryptedLetters.push( {
                date: letter.date,
                msg: decryptMessage(letter.msg)
            });
        }
    });
};
var reload = function( cb ) {
    if (! cb )
        cb = function(){};
    superagent
        .get("/etat")
        .send()
        .end( function(err, res) {
            if (err) return cb(err);
            etat = res.body;
            cb(null);
        });
}

var addAddress = function(name, pem) {
    // var pem = prompt("Public key");
    if (! pem ) {
        var randomKey = new NodeRSA({b: 512});
        pem = randomKey.exportKey('public');
    }
    etat.yp[pem] = {name: name, pem: pem};
    superagent
        .post("/addAddress")
        .send({pem:pem, name:name})
        .end(console.log.bind(console));
};

var newMessage = function(text, address) {
    var pubKey = new NodeRSA(address);
    var msg = {date:new Date(), to: address, msg: pubKey.encrypt(text,'base64')};
    console.log(JSON.stringify(msg, null, 2));
    superagent
        .post("/postMessage")
        .send(msg)
        .end(console.log.bind(console));
}

var redraw_view = function() {
    var $content;
    var $textarea_msgcontent = $('<textarea>');
    switch($focus.val()) {
    case "inbox" :
        populateDecryptedLetters();
        var $list = $('<ul>');
        decryptedLetters.forEach( function(letter) {
            $list.append($('<li>').append(
                $('<a href="#">').append("Date: "+letter.date).css('font-weight','bold').click(function(){
                    $textarea_msgcontent.empty().append(letter.msg)

                              $("ul.b > li").css('font-weight','bold');
                              $(this).css('font-weight','normal'); //to change font to show message read


                }))
            );
        });
        var $reload = $('<button>').append("Reload")
            .click(function(){ reload( function() {

              pem = CryptoJS.AES.decrypt(etat.encryptedKey, password)
                  .toString(CryptoJS.enc.Utf8);
              key = new NodeRSA(pem);
          //

              decryptMessage();
              populateDecryptedLetters();
              redraw_view();
            }) });
        $content =  [$list, $reload];
        break;
    case "write" :
  //      var $textarea = $('<textarea>');
        var $addresses = Object.keys(etat.yp).map( function( addr ) {
          return $('<option value="'+addr+'">').append(etat.yp[addr].name);
        });
        var $to = $('<select>').append( $addresses );
        var $newMessage = $('<button>').append("Send Message")
            .click(function(){
                newMessage($textarea_msgcontent.val(), $to.val());
                $textarea_msgcontent.val("");
                reload( populateDecryptedLetters );
                window.alert("Message sent");
            } );
        $content = [ "Compose a new message to:", $to,"<br>" ,$textarea_msgcontent,"<br>",  $newMessage ];
        break;
    case "yp" :
        var $list = $('<ul>');
        Object.keys(etat.yp).forEach( function(pem) {
            var entry = etat.yp[pem];
            $list.append($('<li>').append(
                $('<a href="#">').append(entry.name).click(function(){
                    alert(JSON.stringify(entry));
                }))
            );
        });
        var $newAddress = $('<button>').append("New Contact")

            .click(function(){
              var new_name = prompt("Enter full name");

              addAddress(new_name); redraw_view(); });
        $content =  ["Contacts", $list, $newAddress ];
        break;
    };
    $body.empty().append($content,"<br><br><br>Contenu du message:<br>",$textarea_msgcontent);
    $body.append($dialog);
};

$focus.change( redraw_view );


reload( function(err) {
    if (err) return console.error(err);
    if (! etat.encryptedKey) {
        // we do not have our key yet
        key = new NodeRSA({b: 512});
        var name = prompt("My full name");
        password = prompt("New password");
        etat.encryptedKey = CryptoJS.AES.encrypt(key.exportKey(), password)
            .toString();
        superagent
            .post("/storeEncryptedKey")
            .send({encryptedKey: etat.encryptedKey})
            .end(console.log.bind(console));
        // add my public key to the yp
        addAddress((name || "me"), key.exportKey('public'));
    } else while (true) {
        var pem = null;
        try {

            password = prompt("Password check:");
            pem = CryptoJS.AES.decrypt(etat.encryptedKey, password)
                .toString(CryptoJS.enc.Utf8);
            key = new NodeRSA(pem);
  //
            break;
        } catch (e) {
            alert("Try again...");
        }
    }

    // build decrypted list of messages
    populateDecryptedLetters();
    redraw_view();
});
