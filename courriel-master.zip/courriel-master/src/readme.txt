README.TXT

This application is able to communicate using node.js and a server etat.json

Known issue: the inbox is not refreshed unless the webpage is reloaded.

Functionalities:

- Text of inbox changing to indicate message has been read.
- Creation of new contacts
- Live content of message displaying on a textfield

Jaime Mario Perez Rojas 2016

